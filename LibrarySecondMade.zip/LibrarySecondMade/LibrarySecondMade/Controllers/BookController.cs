﻿
using System.Data.Common;
using System.Reflection;

namespace LibrarySecondMade.Controllers
{
    [Authorize]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private readonly LDbContext ctx;
        const int pageSize =12;
        public BookController(LDbContext context)
        {
            ctx = context;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Book>>> GetBooks([FromQuery] String? keyWord, [FromQuery] int page)
        {
            List<Book>? books = null; 
            if(keyWord == null)
            {
                books =await ctx.books.Skip((page-1)*pageSize).Take(pageSize).ToListAsync();
            }
            else books = await ctx.books.Where(e => e.Name.Contains(keyWord)|| e.AuthorNames.Contains(keyWord)||e.Press.Contains(keyWord)
             ||e.Type==keyWord).Skip((page-1)*pageSize).Take(pageSize).ToListAsync();
            return await Task.FromResult(books);
        }
        [HttpGet]
        public async Task<ActionResult<int>> GetBookCount([FromQuery] String? keyWord)
        {
            if (keyWord == null)
                return await ctx.books.CountAsync();
            else return await ctx.books.Where(e => e.Name.Contains(keyWord) || e.AuthorNames.Contains(keyWord) || e.Press.Contains(keyWord)
             || e.Type == keyWord).CountAsync();
        }
        [HttpPost]
        public async Task<ActionResult<bool>> GetBorrowed([FromBody]BorrowingBookModel model)
        {
            Book? book =await ctx.books.SingleOrDefaultAsync(e=>e.Id==model.bookId);
            User? user = await ctx.users.SingleOrDefaultAsync(e => e.Id == model.userId);
            BorrowingBook? book1 = await ctx.borrowingBooks.SingleOrDefaultAsync(e => e.UserId == user.Id&&e.BookId==model.bookId);
            bool result = false;
            if(book.RestNum>0&&book1==null&&user.BorrowingCount>0)
            {
                BorrowingBook b=new BorrowingBook();
                b.setUserId(user.Id);
                b.setBookId(model.bookId);
                b.BorrowingTime=DateTime.Now;
                b.ReturnTime = b.BorrowingTime.AddDays(30);
                ctx.borrowingBooks.Add(b);
                book.RestNum--;
                user.BorrowingCount--;
                b.RenewCount = 3;
                result=true;
                await ctx.SaveChangesAsync();
            }
            return await Task.FromResult(result);
        }
        [HttpPost]
        public async Task GetReturned([FromBody]BorrowingBookModel model)
        {  
           User user=await ctx.users.SingleOrDefaultAsync(e=>e.Id==model.userId);
           BorrowingBook borrowingBook = await ctx.borrowingBooks.SingleOrDefaultAsync(e => e.BookId == model.bookId && e.UserId ==user.Id);
           Book book = await ctx.books.SingleOrDefaultAsync(e => e.Id == model.bookId);
           borrowingBook.RenewCount = 3;
           user.BorrowingCount++;
           book.RestNum++;
           ctx.borrowingBooks.Remove(borrowingBook);
           await ctx.SaveChangesAsync();
        }
        [HttpPost]  
        public async Task<ActionResult<IEnumerable<Book>>> GetBorrowedBooks([FromBody]BorrowingBookModel model)
        {
            /* List<BorrowingBook> books1=await ctx.borrowingBooks.Where(e=>e.UserId==model.userId).ToListAsync();
             List<Book> books2 = new List<Book>();
             foreach (BorrowingBook book in books1)
             {
                 books2.Add(await ctx.books.SingleAsync(e=>e.Id==book.BookId));
             }
             return await Task.FromResult(books2);*/
            String sql = $"select book.Id,book.Name,book.AuthorNames,book.publishDay,book.Type,book.Brief,book.Press,book.RestNum,book.Price from book,borrowingbook as b where book.Id=b.bookId and b.userId={model.userId}";
            DbConnection connection = ctx.Database.GetDbConnection();
            connection.Open();
            DbCommand cmd =connection.CreateCommand();
            cmd.CommandText = sql;
            List<Book> books = null;
            using(DbDataReader reader = cmd.ExecuteReader())
            {
               books=SqlExeReader.SqlRead<Book>(reader).ToList();
            }
            connection.Close();
            return await Task.FromResult(books);
        }
        [HttpGet]
        public async Task<ActionResult<List<String []>>> GetBorrowAndReturnOptions([FromQuery]String? userId)
        {
            List<String[]> result = new List<string[]>();
           BorrowingBook[] books=await ctx.borrowingBooks.Where(x=>x.UserId == userId).ToArrayAsync();
            foreach (var book in books)
            {
                String[] res = new String[3];
                res[0] = book.BorrowingTime.ToString("yyyy-MM-dd HH:mm:ss");
                res[1] = book.ReturnTime.ToString("yyyy-MM-dd HH:mm:ss");
                res[2] = book.RenewCount.ToString();
                result.Add(res);
            }
            return await Task.FromResult(result);
        }
        [HttpPut]
        public async Task<ActionResult<String>> GetRenewed([FromBody]BorrowingBookModel model)
        {
            BorrowingBook book = await ctx.borrowingBooks.SingleOrDefaultAsync(e => e.BookId == model.bookId && e.UserId == model.userId);
            switch (book.RenewCount)
            {
                case 3:book.ReturnTime = book.ReturnTime.AddDays(21);break;
                case 2:book.ReturnTime=book.ReturnTime.AddDays(14);break;
                case 1:book.ReturnTime=book.ReturnTime.AddDays(7);break;
            }
            if (book.RenewCount > 0)
            {
                book.RenewCount--;
                await ctx.SaveChangesAsync();
            }
            return await Task.FromResult(book.ReturnTime.ToString("yyyy-MM-dd HH:mm:ss"));
        }
    }
}
