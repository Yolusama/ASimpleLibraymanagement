﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace LibrarySecondMade.Controllers
{
    [Authorize]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly LDbContext ctx;
        const int pageSize = 6;
        public AdminController(LDbContext context)
        {
            this.ctx = context;
        }
        [HttpDelete]
        public async Task DeleteBook([FromQuery] string? bookId)
        {
            await ctx.Database.ExecuteSqlRawAsync($"delete from book where Id={bookId}");
            await ctx.Database.ExecuteSqlRawAsync($"delete from borrowingbook where bookId={bookId}");
        }
        [HttpPut]
        public async Task AddBook([FromBody] BookModel model)
        {
            Book book = new Book(model.id, model.press);
            book.Name=model.name;
            book.AuthorNames = model.authorNames;
            book.RestNum = model.restNum;
            book.Brief = model.brief;
            book.setPrice(model.price);
            book.Type = model.type;
            book.publishDay = model.publishDay;
            ctx.books.Add(book);
            await ctx.SaveChangesAsync();
        }
        [HttpPut]
        public async Task UpdateBook([FromBody] BookModel model)
        {
            Book book=await ctx.books.SingleOrDefaultAsync(e=>e.Id==model.id);
            if(book.Name!=model.name)
            book.Name = model.name;
            if(book.AuthorNames!=model.authorNames)
            book.AuthorNames = model.authorNames;
            if(book.RestNum!=model.restNum)
            book.RestNum = model.restNum;
            if(book.Brief!=model.brief)
            book.Brief = model.brief;
            if(book.Price!=model.price)
            book.setPrice(model.price);
            if(book.Type!=model.type)
            book.Type = model.type;
            if(book.publishDay!=model.publishDay)
            book.publishDay = model.publishDay;
            await ctx.SaveChangesAsync();
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Book>>> GetBooks([FromQuery]int page,[FromQuery] string? keyWord)
        {
            if (keyWord == null)
            {
                return await ctx.books.Skip((page-1)*pageSize).Take(pageSize).ToListAsync();
            }
            else return await
                    ctx.books.Where(e=>e.Name.Contains(keyWord)||e.AuthorNames.Contains(keyWord)||e.Type==keyWord).Skip((page-1)*pageSize).Take(pageSize).ToListAsync();
        }
        [HttpPut]
        public async Task ToBeAdmin([FromQuery]String? userId)
        {
            User? u = await ctx.users.SingleOrDefaultAsync(e => e.Id == userId||e.Email==userId);
            u.ChangeRole("管理员");
            BorrowingBook[] borrowingBooks=ctx.borrowingBooks.Where(e=>e.UserId==userId).ToArray();
            ctx.RemoveRange(borrowingBooks);
            await ctx.SaveChangesAsync();
            foreach (var book in borrowingBooks)
            await ctx.Database.ExecuteSqlRawAsync($"update book set RestNum=RestNum+1 where Id={book.BookId}");
        }
    }
}
