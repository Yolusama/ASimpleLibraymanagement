﻿using System.Linq;

namespace LibrarySecondMade.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly LDbContext ctx;
        MailMessageSender sender { get; }
        RedisCache redis { get; }
        public UserController(LDbContext context,MailMessageSender sender,RedisCache redis)
        {
            ctx = context;
            this.sender = sender;
            this.redis = redis;
        } 
        [Authorize]
        [HttpPost]
        public async Task<ActionResult<bool>> ToLoad([FromBody] UserModel user)
        {
            User u = ctx.users.SingleOrDefault(e => e.Id == user.account||e.Email==user.account);
            u.LastLoginTime = DateTime.Now;
            await ctx.SaveChangesAsync();
            return await Task.FromResult(u.Role == "普通用户");
        }
        [Authorize]
        [HttpGet]
        public async Task<ActionResult<User>> LoadBy([FromQuery]string? account)
        { 
            return await ctx.users.SingleOrDefaultAsync(e => e.Id == account||e.Email==account);
        }
        [HttpPost]
        public async Task<ActionResult<String>> GetToken([FromBody]UserModel user)
        {
            User? u=ctx.users.SingleOrDefault(e => e.Id == user.account||e.Email==user.account);
            if (u == null) return await Task.FromResult("401");
            if (u.Password == HashSecurity.Hash(user.password))
                return await Task.FromResult(JwtGenerator.Generate(u.Id, u.Role));
            else return await Task.FromResult("密码错误");
        }
        [HttpPut("/api/User/Register/{SecureCode}")]
        public async Task<ActionResult<String>> Register([FromRoute]string? SecureCode,[FromBody]UserModel user)
        {
            User U=ctx.users.SingleOrDefault(e => e.Email == user.email);
            if (U != null)
                return await Task.FromResult("Error");
            string trueCode = redis[0].StringGet("code").ToString().Split(":")[1];
            if (SecureCode == trueCode)
            {
                User u = new User(AccountGenerator.Generate());
                u.ChangeEmail(user.email);
                u.RegisterDay = DateOnly.FromDateTime(DateTime.Now);
                u.Name = user.name;
                u.ChangeRole("普通用户");
                u.ChangePassword(HashSecurity.Hash(user.password));
                u.BorrowingCount = 15;
                ctx.users.Add(u);
                await ctx.SaveChangesAsync();
                return await Task.FromResult(u.Id);
            }
            else return await Task.FromResult("Error");
        }
        [HttpPut("/api/User/ResetPwd/{email}/{newPassword}/{secureCode}")]
        public async Task<ActionResult<bool>> ResetPwd([FromRoute]string? email,[FromRoute]string?newPassword,[FromRoute]string? secureCode)
        {
            string code=redis[0].StringGet("code").ToString().Split(":")[1];
            User user = await ctx.users.SingleOrDefaultAsync(e => e.Email == email);
            if(HashSecurity.Hash(newPassword)==user.Password)
                return await Task.FromResult(false);
            if (code == secureCode)
            { 
                user.ChangePassword(HashSecurity.Hash(newPassword));
                await ctx.SaveChangesAsync();
                return await Task.FromResult(true);
            }
            return await Task.FromResult(false);
        }
        [HttpPost]
        public void SendForCode([FromQuery]String? email,[FromQuery]int count)
        {
            string code = SecureCodeGenerator.Generate(count);
            sender.sendTo(email,code);
            redis[0].StringSet("code", $"{email}:{code}",TimeSpan.FromMinutes(5));
        }
        [Authorize]
        [HttpGet]
        public async Task<ActionResult<User>> GetSelfInfo([FromQuery] string? Account)
        {
            return await this.ctx.users.SingleOrDefaultAsync(e=>e.Id == Account);
        }
        [Authorize]
        [HttpPost("/api/User/ChangeEmail/{secureCode}")]
        public ActionResult<Boolean> ChangeEmail([FromBody]UserModel user,[FromRoute]string? secureCode)
        {
            bool result = false;
            string trueCode = redis[0].StringGet("code").ToString().Split(":")[1];
            if (trueCode == secureCode)
            {
               User u=ctx.users.Single(e=>e.Email==user.account);
               u.ChangeEmail(user.email);
               ctx.SaveChanges();
               result = true;
            }
            else result=false;
            return result;
        }
        [Authorize]
        [HttpPut]
        public async Task ChangePwd([FromBody]UserModel model)
        {
            User u=await ctx.users.SingleAsync(e=>e.Id==model.account||e.Email==model.account);
            u.ChangePassword(HashSecurity.Hash(model.password));
            await ctx.SaveChangesAsync();
        }
        [Authorize]
        [HttpPost]
        public async Task<ActionResult<bool>> VerifyPwd([FromBody]UserModel model)
        {
            User u = await ctx.users.SingleAsync(e => e.Id == model.account||e.Email==model.account);
            string hash=HashSecurity.Hash(model.password);
            return await Task.FromResult(u.Password==hash);
        }
        [Authorize]
        [HttpPut]
        public async Task ChangeName([FromBody]UserModel model)
        {
            User u=await ctx.users.SingleAsync(e=>e.Id == model.account||e.Email==model.account);
            u.Name = model.name;
            await ctx.SaveChangesAsync();
        }
    }
}
