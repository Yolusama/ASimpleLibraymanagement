﻿namespace LibrarySecondMade.Models
{
    public class BookModel
    {
        public string? id { get; set; }
        public string? name { get; set; }
        public string? authorNames { get; set; }
        public DateOnly publishDay { get; set; }
        public string? type { get; set; }
        public string? brief { get; set; }
        public string? press { get; set; }
        public int restNum { get; set; }
        public int price { get; set; }
    }
}
