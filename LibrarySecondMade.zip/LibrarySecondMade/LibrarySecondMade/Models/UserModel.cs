﻿namespace LibrarySecondMade.Models
{
    public record UserModel
    {
        public String? account { get; set; }
        public String? password { get; set; }
        public String? email { get; set; }
        public String? name { get; set; }
    }
}
