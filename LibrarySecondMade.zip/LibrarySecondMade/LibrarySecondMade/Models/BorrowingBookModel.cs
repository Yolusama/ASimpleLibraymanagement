﻿namespace LibrarySecondMade.Models
{
    public class BorrowingBookModel
    {
        public string? bookId { get; set; }
        public string? userId { get; set; }
        public string? comment { get; set; }
        public int borrowingDays { get; set; }
    }
}
