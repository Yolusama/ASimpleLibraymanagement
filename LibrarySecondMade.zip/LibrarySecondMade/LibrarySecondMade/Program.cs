var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
var locals = new string[] { "http://localhost:8080", "http://localhost:5500" };
builder.Services.AddCors(opt =>
{
    opt.AddDefaultPolicy(op =>
    {
        op.WithOrigins(locals).AllowAnyHeader().AllowCredentials().AllowAnyMethod();
    });
});
builder.Services.AddDbContext<Entity.LDbContext>(opt =>
{
    MySqlServerVersion version = new MySqlServerVersion(new Version(8, 0, 32));
    opt.UseMySql(builder.Configuration["ConnectStr"], version);
});
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(opt =>
{
    opt.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience =true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["Jwt:Issuser"],
        ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:secretKey"]))
    };
});
builder.Services.AddScoped<RedisCache>(op =>
{
    return new RedisCache(builder.Configuration["RedisConnStr"]);
});
JwtGenerator.Issuser = builder.Configuration["Jwt:Issuser"];
JwtGenerator.secretKey = builder.Configuration["Jwt:secretKey"];
JwtGenerator.Audience = builder.Configuration["Jwt:Audience"];
builder.Services.AddScoped<MailMessageSender>();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseCors();

app.UseHttpsRedirection();

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Run();
