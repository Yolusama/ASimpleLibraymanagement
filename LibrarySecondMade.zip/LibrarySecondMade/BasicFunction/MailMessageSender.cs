﻿using System.Net;
using System.Net.Mail;
namespace BasicFunction
{
    public class MailMessageSender
    {
        MailMessage mail;
        public MailMessageSender()
        {
            mail = new MailMessage();
            mail.From = new MailAddress("2504319659@qq.com");
        }
        public void sendTo(String To,String code)
        {
            mail.To.Clear();
            mail.To.Add(To);
            mail.Subject = "验证码";
            mail.Body = $"亲爱的{To}这是你的验证码：{code},请在五分钟之内使用！";
           using (SmtpClient client=new SmtpClient("smtp.qq.com",587))
            { 
                client.EnableSsl = true;
                client.Credentials = new NetworkCredential("2504319659@qq.com", "rttpayockokcdief");//password参数为邮箱中生成stmp的授权码
                client.Send(mail);
            }
        }
    }
}
