﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace BasicFunction
{
    public static class JwtGenerator
    {
        public static String secretKey;
        public static String Issuser;
        public static String Audience;
        public static String Generate(string Account,string Role)
        { 
       
            List<Claim> list = new List<Claim>();
            list.Add(new Claim(ClaimTypes.Name, Account));
            list.Add(new Claim(ClaimTypes.NameIdentifier, Role));
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey));
            var token = new JwtSecurityToken(
                Issuser,
                Audience,
                list,
                expires: DateTime.Now.AddDays(7d),
                signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256Signature)
                );
            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
