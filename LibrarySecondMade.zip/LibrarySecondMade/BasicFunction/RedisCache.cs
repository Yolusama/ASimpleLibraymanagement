﻿using StackExchange.Redis;
namespace BasicFunction
{
    public class RedisCache
    {
        ConnectionMultiplexer redis;
        public RedisCache() { }
        public RedisCache(String ConnectStr)
        {
            redis=ConnectionMultiplexer.Connect(ConnectStr);
        }
        public void Connect(String ConnectStr)
        {
            if(!redis.IsConnected)
             ConnectionMultiplexer.Connect(ConnectStr);
        }
        public IDatabase GetDatabase(int index) { return redis.GetDatabase(index); }
        public IDatabase this[int index]=>GetDatabase(index);
    }
}
