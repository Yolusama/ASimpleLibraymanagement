﻿
namespace BasicFunction
{
    public static  class SecureCodeGenerator
    {
        public static string Generate(int count = 4)
        {
            String code = "";
            for(int i = 0; i < count; i++)
            {
                code+=Random.Shared.Next(0,10).ToString();
            }
            return code;
        }
    }
}
