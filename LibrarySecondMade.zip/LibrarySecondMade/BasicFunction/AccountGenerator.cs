﻿
namespace BasicFunction
{
    public static class AccountGenerator
    {
        public static String Generate()
        {
            Random random = new Random(DateTime.Now.Millisecond);
            int len=random.Next(8,11);
            String account = random.Next(1, 10).ToString();
            for(int i = 1; i < len; i++)
            {
                account+=random.Next(0,10).ToString();
            }
            return account;
        }
    }
}
