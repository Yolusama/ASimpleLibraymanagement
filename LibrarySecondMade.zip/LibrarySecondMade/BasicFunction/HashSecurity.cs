﻿global using System;
global using System.Collections.Generic;
global using System.Linq;
global using System.Text;
global using System.Threading.Tasks;
using System.Security.Cryptography;

namespace BasicFunction
{
    public static class HashSecurity
    {
        public static string Hash(String? pwd)
        {
            if(pwd == null)return String.Empty;
            using(MD5 MD = MD5.Create())
            {
                byte[] Obytes=Encoding.UTF8.GetBytes(pwd);
                byte[] hash=MD.ComputeHash(Obytes);
                return Convert.ToBase64String(hash);
            }
        }
    }
}
