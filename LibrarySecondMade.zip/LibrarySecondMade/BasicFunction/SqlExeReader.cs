﻿using System.Data.Common;
using System.Reflection;

namespace BasicFunction
{
    public static class SqlExeReader
    {
        public static IEnumerable<T> SqlRead<T>(DbDataReader reader)
        {
            List<T> books = new List<T>();
            Type type = typeof(T);
            PropertyInfo[] pros = type.GetProperties();
                while (reader.Read())
                {
                    object book = Activator.CreateInstance(type);
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        if (pros[i].PropertyType.FullName.Contains("Date"))
                        {
                            if (pros[i].PropertyType.FullName.Contains("DateOnly"))
                                pros[i].SetValue(book, DateOnly.FromDateTime((DateTime)reader.GetValue(i)));
                            else pros[i].SetValue(book, (DateTime)reader.GetValue(i));
                        }
                        else if (pros[i].PropertyType.FullName.Contains("Int"))
                        {
                            Console.Write(reader.GetValue(i));
                            pros[i].SetValue(book, (int)reader.GetValue(i));
                        }
                        else pros[i].SetValue(book, reader.GetValue(i));
                    }
                    books.Add((T)book);
                }
            return books;
        }
    }
}
