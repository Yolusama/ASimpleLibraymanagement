﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Entity.Migrations
{
    /// <inheritdoc />
    public partial class e : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BorrowingDays",
                table: "borrowingbook");

            migrationBuilder.DropColumn(
                name: "Comment",
                table: "borrowingbook");

            migrationBuilder.AddColumn<int>(
                name: "RenewCount",
                table: "User",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<DateTime>(
                name: "BorrowingTime",
                table: "borrowingbook",
                type: "datetime(6)",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ReturnTime",
                table: "borrowingbook",
                type: "datetime(6)",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.CreateIndex(
                name: "IX_borrowingbook_BookId",
                table: "borrowingbook",
                column: "BookId");

            migrationBuilder.CreateIndex(
                name: "IX_borrowingbook_UserId",
                table: "borrowingbook",
                column: "UserId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_borrowingbook_BookId",
                table: "borrowingbook");

            migrationBuilder.DropIndex(
                name: "IX_borrowingbook_UserId",
                table: "borrowingbook");

            migrationBuilder.DropColumn(
                name: "RenewCount",
                table: "User");

            migrationBuilder.DropColumn(
                name: "BorrowingTime",
                table: "borrowingbook");

            migrationBuilder.DropColumn(
                name: "ReturnTime",
                table: "borrowingbook");

            migrationBuilder.AddColumn<int>(
                name: "BorrowingDays",
                table: "borrowingbook",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "Comment",
                table: "borrowingbook",
                type: "longtext",
                nullable: false)
                .Annotation("MySql:CharSet", "utf8mb4");
        }
    }
}
