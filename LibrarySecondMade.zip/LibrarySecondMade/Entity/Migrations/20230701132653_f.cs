﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Entity.Migrations
{
    /// <inheritdoc />
    public partial class f : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "RenewCount",
                table: "User");

            migrationBuilder.AddColumn<int>(
                name: "RenewCount",
                table: "borrowingbook",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "RenewCount",
                table: "borrowingbook");

            migrationBuilder.AddColumn<int>(
                name: "RenewCount",
                table: "User",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
