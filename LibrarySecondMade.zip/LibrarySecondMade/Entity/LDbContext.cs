﻿global using Pomelo.EntityFrameworkCore.MySql;
using System.Reflection;

namespace Entity
{
    public class LDbContext:DbContext
    {
        public DbSet<User> users { get; private set; }
        public DbSet<Book> books { get; private set; }
        public DbSet<BorrowingBook> borrowingBooks { get; private set; }
        public LDbContext(DbContextOptions options) : base(options) { }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
        }
    }
}
