﻿namespace Entity
{
    public class Book
    {
        public String Id { get; init; }
        public String Name { get; set; }
        public String AuthorNames { get; set; }
        public DateOnly publishDay { get; set; }
        public String Type { get; set; }
        public String Brief { get; set; }
        public String Press { get; init; }
        public int RestNum { get; set; }
        public int Price { get; private set; }
        public Book() { }
        public Book(String Id,String Press)
        {
            this.Id = Id;
            this.Press = Press;
        }
        public void setPrice(int price)
        {
            Price = price;
        }
    }
    class BookConfig : IEntityTypeConfiguration<Book>
    {
        public void Configure(EntityTypeBuilder<Book> builder)
        {
            builder.ToTable("book");
            builder.Property(x => x.Id).ValueGeneratedNever().HasMaxLength(20);
            builder.HasKey(x=>x.Id);
            builder.Property(x=>x.Name).HasMaxLength(30).IsRequired();
            builder.Property(x=>x.AuthorNames).HasMaxLength(50).IsRequired();
            builder.Property(x=>x.Type).HasMaxLength(10).IsRequired();
            builder.HasIndex(x => x.Type);
            builder.HasIndex(x=>x.Press);
            builder.Property(x=>x.Press).HasMaxLength(25).IsRequired();
            builder.Property(x=>x.RestNum).IsRequired();
            builder.Property(x=>x.publishDay).IsRequired();
        }
    }
}
