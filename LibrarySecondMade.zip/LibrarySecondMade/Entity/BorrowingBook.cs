﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class BorrowingBook
    {
        public long Id { get;private set; }
        public String UserId { get; private set; }
        public String BookId { get; private set; }
        public int RenewCount { get; set; }
        public DateTime BorrowingTime { get;set; }
        public DateTime ReturnTime {get;set; }
        public BorrowingBook() { }
        public BorrowingBook(String UserId,String BookId)
        {
            this.BookId = BookId;
            this.UserId = UserId;
        }
        public void setUserId(String UserId)
        {
            this.UserId=UserId;
        }
        public void setBookId(String BookId)
        {
            this.BookId=BookId;
        }
    }
    class BorrowingBookConfig : IEntityTypeConfiguration<BorrowingBook>
    {
        public void Configure(EntityTypeBuilder<BorrowingBook> builder)
        {
            builder.ToTable("borrowingbook");
            builder.HasKey(t => t.Id);
            builder.Property(t => t.UserId).IsRequired().HasMaxLength(20);
            builder.Property(t=>t.BookId).IsRequired().HasMaxLength(25);
            builder.HasIndex(t => t.UserId);
            builder.HasIndex(t => t.BookId);
        }
    }
}
