﻿global using Microsoft.EntityFrameworkCore.Metadata;
global using Microsoft.EntityFrameworkCore;
global using System;
global using System.Collections.Generic;
global using System.Linq;
global using System.Text;
global using System.Threading.Tasks;
global using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Entity
{
    public class User
    {
        public string Id { get; private set; }
        public string Name { get; set; }
        public String Email { get; private set; }
        public String Password { get; private set; }
        public DateOnly RegisterDay { get; set; }
        public DateTime LastLoginTime { get; set; }
        public string Role { get; private set; }
        public int BorrowingCount { get; set; }
        public User() { }
        public User(String Id) { this.Id = Id; }
        public User(String Id, String Name, DateOnly RegisterDay, DateTime LastLoginTime, String Role)
        {
            this.Id = Id;
            this.Name = Name;
            this.RegisterDay = RegisterDay;
            this.LastLoginTime = LastLoginTime;
            this.Role = Role;
        }
        public void ChangePassword(String newPwd)
        {
            Password = newPwd;
        }
        public void ChangeRole(String Role)
        {
            this.Role = Role;
        }
        public void ChangeEmail(String Email)
        {
            this.Email = Email;
        }
    }
    class UserConfig : IEntityTypeConfiguration<User>
    {
        public void Configure(EntityTypeBuilder<User> builder)
        {
            builder.ToTable("User");
            builder.HasKey(x => x.Id);
            builder.Property(x=>x.Id).ValueGeneratedNever().HasMaxLength(20);
            builder.Property(x=>x.Name).HasMaxLength(20).IsRequired();
            builder.HasIndex(x => x.Id).IsUnique();
            builder.Property(x=>x.Email).HasMaxLength(20).IsRequired();
            builder.Property(x=>x.Role).HasMaxLength(10).IsRequired();
        }
    }
}
